export interface Genero{
    nome: string;
    descricao: string;
}