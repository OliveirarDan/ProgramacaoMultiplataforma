export interface Filme{
    nome: string;
    genero: string;
}