import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Filme } from '../../model/filmes';
import { DestinoPage } from '../destino/destino';

/**
 * Generated class for the FilmesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-filmes',
  templateUrl: 'filmes.html',
})
export class FilmesPage {

  public filmes:Filme[];


  constructor(public navCtrl: NavController) {
    var f1 = {nome: 'Logan', genero:'Ação'};
    var f2 = {nome: 'Um lugar silêncioso', genero:'Terror'};
    var f3 = {nome: 'Homem de Ferro', genero:'Ação'};
    var f4 = {nome: 'MIB - Homens de Preto', genero:'Ação'};
    var f5 = {nome: 'Jumanji', genero:'Aventura'};
    var f6 = {nome: 'Venom', genero:'Ação'};

    this.filmes= [f1, f2, f3, f4, f5, f6];
    
  
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FilmesPage');
  }

  irParaDestino(filme:Filme):void{
    this.navCtrl.push(DestinoPage, {filmeSelecionado: filme});
    }

}
