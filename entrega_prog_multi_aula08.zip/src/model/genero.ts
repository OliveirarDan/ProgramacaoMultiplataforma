/*
 *@Author: Danilo Rodrigues Oliveira
 *@RA: 81612248
*/ 

export interface Genero{
    nome: string;
    descricao: string;
  
}