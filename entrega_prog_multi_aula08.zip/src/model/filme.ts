export class Filme{
    id: number;
    titulo: string;
    genero: string;
    
    }
   