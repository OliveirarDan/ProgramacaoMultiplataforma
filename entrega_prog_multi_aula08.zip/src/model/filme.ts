/*
 *@Author: Danilo Rodrigues Oliveira
 *@RA: 81612248
*/ 

export class Filme{
    id: number;
    titulo: string;
    genero: string;
    
    }
   