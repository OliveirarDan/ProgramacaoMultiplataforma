/*
 *@Author: Danilo Rodrigues Oliveira
 *@RA: 81612248
*/ 

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FilmesPage } from './filmes';

@NgModule({
  declarations: [
    FilmesPage,
  ],
  imports: [
    IonicPageModule.forChild(FilmesPage),
  ],
})
export class FilmesPageModule {}
