/*
 *@Author: Danilo Rodrigues Oliveira
 *@RA: 81612248
*/ 

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExibeFilmesPage } from './exibe-filmes';

@NgModule({
  declarations: [
    ExibeFilmesPage,
  ],
  imports: [
    IonicPageModule.forChild(ExibeFilmesPage),
  ],
})
export class ExibeFilmesPageModule {}
